// This file serves as a required fallback for the @calendar parallel route slot.
// It is rendered when the URL does not explicitly include or exclude this slot.
// Returning null ensures the UI remains stable even when the slot is not matched.
export default function CalendarDefault() {
  return null;
}
