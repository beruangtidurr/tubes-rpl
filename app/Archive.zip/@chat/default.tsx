export default function ChatDefault() {
  return null;
}
