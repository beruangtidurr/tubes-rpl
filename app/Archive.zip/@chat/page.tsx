import ChatCard from "../ui/chatCard";

export default function ChatSlot() {
  return (
    <div className="flex flex-col grow p-2">
      <h2 className="text-2xl font-bold mb-4">Chat</h2>
      {/* <div className="flex flex-col space-y-3 overflow-y-auto h-full mb-4">
        <div className="self-start bg-gray-200 p-2 rounded-xl rounded-tl-sm max-w-[80%] text-sm">
          Hey, anyone know the time for the lab session tomorrow?
        </div>
        <div className="self-end bg-blue-500 text-white p-2 rounded-xl rounded-br-sm max-w-[80%] text-sm">
          It's at 2:00 PM in Room B4. Check the latest announcement!
        </div>
        <div className="self-start bg-gray-200 p-2 rounded-xl rounded-tl-sm max-w-[80%] text-sm">
          Thanks! Got it.
        </div>
      </div>
      <div className="mt-auto">
        <input 
          type="text" 
          placeholder="Type a message..." 
          className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div> */}

      <ChatCard title="Artificial Intelligence" team={1}/>
      <ChatCard title="Manajemen Proyek" team={1}/>
      <ChatCard title="Pengantar Sistem Informasi" team={1}/>
    </div>
  );
}
