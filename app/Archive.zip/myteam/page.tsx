// This component will be rendered in the central content area ({children} slot) 
// when the user navigates to the /myteam route.
export default function MyTeamPage() {
  return (
    <div className="flex flex-col grow items-center justify-start font-sans p-4">
      
      {/* Title that replaces "Course" */}
      <h2 className="text-2xl font-bold mb-4 w-full">My Team</h2>

      <h3 className="text-3xl font-bold text-gray-800 mb-6 w-full text-left">My Team Details</h3>
      
      <div className="w-full bg-gray-100 p-6 rounded-lg shadow-lg">
        <p className="text-lg font-semibold mb-3 border-b pb-2">Team Members (RPL Project)</p>
        <ul className="space-y-2">
          <li className="flex justify-between items-center p-2 bg-white rounded-md shadow-sm">
            <span className="font-medium">John Doe</span>
            <span className="text-sm text-gray-500">Leader</span>
          </li>
          <li className="flex justify-between items-center p-2 bg-white rounded-md shadow-sm">
            <span className="font-medium">Jane Smith</span>
            <span className="text-sm text-gray-500">Developer</span>
          </li>
          <li className="flex justify-between items-center p-2 bg-white rounded-md shadow-sm">
            <span className="font-medium">Michael Brown</span>
            <span className="text-sm text-gray-500">Designer</span>
          </li>
        </ul>
      </div>

      <div className="mt-8 w-full bg-gray-100 p-6 rounded-lg shadow-lg">
        <p className="text-lg font-semibold mb-3 border-b pb-2">Team Progress</p>
        <div className="h-4 bg-gray-300 rounded-full">
          <div className="w-[65%] h-full bg-green-500 rounded-full flex items-center justify-end pr-2">
            <span className="text-xs font-bold text-white">65%</span>
          </div>
        </div>
        <p className="text-sm mt-2 text-gray-600">Tasks completed: 13/20</p>
      </div>
      
    </div>
  );
}
