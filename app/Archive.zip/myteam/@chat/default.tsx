// This file acts as the required default fallback for the @calendar slot 
// when inside the /myteam route.
export { default } from "../../@chat/default";
