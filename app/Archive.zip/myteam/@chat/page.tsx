// This file ensures the calendar slot is always rendered 
// when the user is on the /myteam route.
// It references the root page content.
export { default } from "../../@chat/page";
